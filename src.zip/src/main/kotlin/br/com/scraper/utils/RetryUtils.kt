package br.com.scraper.utils

import org.slf4j.LoggerFactory
import kotlin.math.pow
import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

object RetryUtils {
    private val logger = LoggerFactory.getLogger(RetryUtils::class.java)

    fun <T> executeWithRetry(
        maxRetries: Int = 3,
        baseDelay: Duration = 2.seconds,
        retryOn: List<Class<out Exception>> = listOf(Exception::class.java),
        onFailure: ((attempt: Int, exception: Exception) -> Unit)? = null,
        operation: () -> T
    ): T {
        var attempt = 0
        var lastException: Exception? = null

        while (attempt < maxRetries) {
            try {
                logger.info("Tentativa ${attempt + 1}/$maxRetries...")
                return operation()
            } catch (e: Exception) {
                if (retryOn.none { it.isInstance(e) }) throw e
                lastException = e
                onFailure?.invoke(attempt + 1, e)

                val delay = baseDelay.inWholeMilliseconds * 2.0.pow(attempt.toDouble()).toLong()
                logger.warn("Erro na tentativa ${attempt + 1}: ${e.message}. Aguardando ${delay}ms para nova tentativa.")
                Thread.sleep(delay)
                attempt++
            }
        }

        logger.error("Todas as tentativas falharam após $maxRetries tentativas.", lastException)
        throw lastException ?: RuntimeException("Erro desconhecido no retry")
    }
}