package br.com.scraper.model

data class Product(
    val asin: String,
    val title: String,
    val price: String,
    val rating: String,
    val reviews: String
)
