package br.com.scraper.selenium

import io.github.bonigarcia.wdm.WebDriverManager
import org.openqa.selenium.WebDriver
import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.chrome.ChromeOptions
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.firefox.FirefoxOptions
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

@Component
class WebDriverFactory(
    @Value("\${webdriver.browser:chrome}") private val browser: String,
    @Value("\${webdriver.userAgents:}") private val userAgents: String,
    @Value("\${webdriver.arguments:}") private val arguments: String
) {

    private val logger = LoggerFactory.getLogger(WebDriverFactory::class.java)


    fun create(): WebDriver {
        logger.info("Inicializando WebDriver para o navegador: $browser")

        val userAgentList = userAgents.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val argumentList = arguments.split(",").map { it.trim() }.filter { it.isNotEmpty() }

        return when (browser.lowercase()) {
            "chrome" -> {
                WebDriverManager.chromedriver().setup()
                val options = ChromeOptions().apply {
                    argumentList.forEach { addArguments(it) }
                    if (userAgentList.isNotEmpty()) {
                        addArguments("--user-agent=${userAgentList.random()}")
                    }
                }
                ChromeDriver(options)
            }
            "firefox" -> {
                WebDriverManager.firefoxdriver().setup()
                val options = FirefoxOptions().apply {
                    argumentList.forEach { addArguments(it) }
                    if (userAgentList.isNotEmpty()) {
                        addPreference("general.useragent.override", userAgentList.random())
                    }
                }
                FirefoxDriver(options)
            }
            else -> throw IllegalArgumentException("Navegador não suportado: $browser")
        }
    }
}