package br.com.scraper.selenium

import br.com.scraper.utils.RetryUtils
import org.openqa.selenium.WebDriver
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component

@Component
class SeleniumSessionManager(private val webDriverFactory: WebDriverFactory) {

    private val logger = LoggerFactory.getLogger(SeleniumSessionManager::class.java)

    fun <T> useSession(action: (WebDriver) -> T): T {
        val driver = webDriverFactory.create() // Usando o WebDriverFactory injetado

        return try {
            RetryUtils.executeWithRetry {
                action(driver)
            }
        } catch (ex: Exception) {
            logger.error("Erro durante a sessão Selenium", ex)
            throw ex
        } finally {
            logger.info("Encerrando sessão WebDriver")
            driver.quit()
        }
    }
}